#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ -f $Frame_Dir/$1/remove ]]; then
    echo 0
else
    echo 1
fi
