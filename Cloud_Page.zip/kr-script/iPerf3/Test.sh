#!/system/bin/sh

cleanup() {
    pkill -f iperf3
    exit 0
}

trap cleanup SIGINT SIGTERM EXIT

IPERF3="$PREFIX/iperf3"
IPERF3MD5="4bfae4d63da92cb498eeff54838b1ba2"
if [[ ! -f $IPERF3 ]]; then
    echo "正在联网下载iperf3"
    curl -o ${IPERF3} -L https://github.moeyy.xyz/https://github.com/davidBar-On/android-iperf3/raw/refs/heads/gh-pages/libs/arm64-v8a/iperf3.18
fi
md5sum $IPERF3 | grep $IPERF3MD5 > /dev/null
[[ $? -eq 0 ]] || (echo "iperf3下载出现问题" && rm -f $IPERF3)
chmod +x $IPERF3
Parallel=${Parallel:-8}
CMD="$IPERF3 -c $Server -P $Parallel"
echo "服务器地址: $Server"
echo "并行连接数: $Parallel"
if [ "$Receive" = "1" ]; then
    CMD="$CMD -R"
    echo "模式: 接收模式 (从服务器下载)"
else
    echo "模式: 发送模式 (向服务器上传)"
fi
if [ "$Time" = "1" ]; then
    CMD="$CMD -t 0"
    echo "测试时长: 无限"
else
    CMD="$CMD -t 10"
    echo "测试时长: 10秒"
fi
sleep 1
$CMD