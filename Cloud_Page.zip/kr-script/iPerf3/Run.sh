#!/system/bin/sh
IPERF3="$PREFIX/iperf3"
IPERF3MD5="4bfae4d63da92cb498eeff54838b1ba2"

cleanup() {
    pkill -f iperf3
    exit 0
}

trap cleanup SIGINT SIGTERM EXIT

if [[ ! -f $IPERF3 ]]; then
    echo "正在联网下载iperf3"
    curl -o ${IPERF3} -L https://github.moeyy.xyz/https://github.com/davidBar-On/android-iperf3/raw/refs/heads/gh-pages/libs/arm64-v8a/iperf3.18
fi
md5sum $IPERF3 | grep $IPERF3MD5 > /dev/null
[[ $? -eq 0 ]] || (echo "iperf3下载出现问题" && rm -f $IPERF3)
chmod +x $IPERF3
alias iperf3=$IPERF3

IP_ADDR=$(ip route | grep default | awk '{print $5}' | xargs -n1 ip addr show | grep "inet " | grep -v "127.0.0.1" | awk '{print $2}' | cut -d'/' -f1)
echo "当前的IP地址：$IP_ADDR"

iperf3 -s