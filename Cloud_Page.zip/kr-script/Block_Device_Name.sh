version=10
jian="$Data_Dir/by_name.log"
log="$Data_Dir/Block_Device_version.log"
[[ -f $log ]] && user_version=`cat $log` || user_version=0
if [[ $user_version -lt $version || ! -f $jian ]]; then
a=0
b=(`ls /dev/block/`)
    for i in ${b[@]}; do
        [[ -d /dev/block/$i ]] && unset b[$a]
        a=$((a+1))
    done
        rm -rf $jian &>/dev/null
        echo $version >$log
        AWK=`awk -where 2>/dev/null`
        BLOCKDEV=`which blockdev`
    
            # 优化1：预先构建路径映射表，避免在循环中重复调用 find
            tmp_map="$Data_Dir/block_map.tmp"
            find /dev/block -type l | while read link; do
                echo "$(basename "$link"):$link"
            done | sort -u > "$tmp_map"
            
            find /dev/block -type l | while read o; do
                [[ -d "$o" ]] && continue
                c=`basename "$o"`
                echo ${b[@]} | grep -q "$c" && continue
                echo $c
            done | sort -u | while read Row; do
                # 优化2：用 case 快速过滤包名，比 grep 快
                case "$Row" in
                    com.*) continue ;;
                esac
                
                # UUID 需要精确匹配，还是用 grep
                echo "$Row" | grep -qE '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' && continue
                
                # 优化3：从映射表中查找，而不是每次都调用 find
                BLOCK=`grep "^${Row}:" "$tmp_map" | cut -d: -f2- | head -n 1`
                [[ -z "$BLOCK" ]] && continue
                
                    if [[ -n $AWK && -n $BLOCKDEV ]]; then   
                        size=`blockdev --getsize64 $BLOCK 2>/dev/null`
                        [[ -z "$size" ]] && continue
                        
                        # 使用 awk 处理大数字
                        File_Type=`awk -v s="$size" 'BEGIN {
                            if (s >= 1073741824) {
                                printf "%.2fG", s/1073741824
                            } else if (s >= 1048576) {
                                printf "%.2fMB", s/1048576
                            } else if (s >= 1024) {
                                printf "%.2fKB", s/1024
                            } else {
                                printf "%db", s
                            }
                        }'`
                            echo "$BLOCK|$Row 「大小：$File_Type」" >>$jian
                    else
                        echo "$BLOCK|$Row" >>$jian
                    fi
            done
            
            # 清理临时文件
            rm -f "$tmp_map"
fi
cat $jian