#!/system/bin/sh
FILE="/data/adb/bootanimation_make"
FFMPEG="$PREFIX/ffmpeg"
FFMPEGMD5="efab65c8885bd5594996d41fd5d13b1b"
mkdir -p $FILE
if [[ ! -f $FFMPEG ]]
then
	echo "正在联网下载FFmpeg"
	cd $FILE
	curl -LO https://fuckgjzs.people11c.workers.dev/People-11/FuckGJZS/main/Misc/ffmpeg/ffmpeg.a[a-u]
	cat ffmpeg.a* > ffmpeg
	cp -f ffmpeg $FFMPEG
	cd - > /dev/null
fi

md5sum $FFMPEG | grep $FFMPEGMD5 > /dev/null
[[ $? -eq 0 ]] || (echo "FFmpeg下载出现问题" && rm -f $FFMPEG)

chmod 777 $FFMPEG
alias ffmpeg=$FFMPEG