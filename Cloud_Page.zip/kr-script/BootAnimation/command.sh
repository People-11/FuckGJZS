#!/system/bin/sh
FILE="/data/adb/bootanimation_make"
FFMPEG="$PREFIX/ffmpeg"
FFMPEGMD5="efab65c8885bd5594996d41fd5d13b1b"
mkdir -p $FILE
if [[ ! -f $FFMPEG ]]; then
	echo "正在联网下载FFMPEG"
	cd $FILE
	curl -LO https://cloud.ananas.chaoxing.com/view/fileviewDownload?objectId=d153520a7d6f742b266bd54d944869b8
	cat ffmpeg.bin > ffmpeg
	cp -f ffmpeg $FFMPEG
	cd - > /dev/null
fi

md5sum $FFMPEG | grep $FFMPEGMD5 > /dev/null
[[ $? -eq 0 ]] || (echo "FFMPEG下载出现问题" && rm -f $FFMPEG)

chmod 777 $FFMPEG
alias ffmpeg=$FFMPEG