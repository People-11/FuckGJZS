#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ -n $hide ]]; then
    for i in $hide; do
        pm hide $i
        echo "已隐藏$i"
        echo "$i" >>$Data_Dir/Hidden_app_Records.log
    done
    echo "已记录隐藏的应用到数据目录，清除搞机助手全部数据会导致记录丢失"
fi


if [[ -n $unhide ]]; then
    for o in $unhide; do
        pm unhide $o
        echo "已恢复$o"
        echo "$o" >>$Data_Dir/Hidden_app_Records.log
    done
fi
