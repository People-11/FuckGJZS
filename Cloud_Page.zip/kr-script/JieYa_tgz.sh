#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上



echo "Dir=$Dir" >$Data_Dir/JieYa_tgz.log
Dir2=${Source_File%/*}
Dir3="${Dir:="$Dir2"}"
name="${Source_File##*/}"
name2="$Dir3/${name%.*}"

[[ ! -d "$name2" ]] && mkdir -p "$name2"
echo "正在解压中"
echo "如果出现红色字体就是解压失败，请尝试用专业解压缩软件解压"
echo
tar -zxvf "$Source_File" -C "$name2" 1>/dev/null
code=$?
[[ $code -ne 0 ]] && echo "返回码：$code";
echo "解压文件输出目录路径："$name2""
