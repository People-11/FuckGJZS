#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

if [[ -n $Screen_Size_X && -n $Screen_Size_Y ]]; then
    wm size ${Screen_Size_X}x${Screen_Size_Y}
    if [[ $Revert = 1 ]]; then
        for i in $(seq 10 -1 1); do
        echo "将在$i 秒后重置分辨率，请及时退出"
        sleep 1
        done
        wm size reset
    fi
fi