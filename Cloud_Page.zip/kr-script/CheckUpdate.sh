#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


V() {
    Configuration=`grep_prop Configuration $Load`
    echo "云端页面：`cat $Data_Dir/Cloud_Version.log`"
    echo "功能版本：$Util_Functions_Code"
    echo "配置版本：$Configuration"
    echo "$1版本：$Version_Name（$Version_code）"
}

if [[ -f $Core ]]; then
    if [[ $Version_code -lt $New_Code ]]; then
        echo "当前版本：$Version_Name（$Version_code）"
        echo "最新版本：$New_Version（$New_Code）"
        echo
        echo "推荐在 github.com/People-11/FuckGJZS 中下载最新的APK，并且卸载旧版后安装"
    elif [[ $Version_code -eq $New_Code ]]; then
        V 软件
    else
        echo "未知版本：$Version_Name（$Version_code）"
    fi
elif [[ ! -s $Core ]]; then
        echo -e "连接服务器失败"
fi
