#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


for i in $package; do
   if [[ $i == $Package_name ]]; then
      echo "?"
   else
   pm hide $i
      if [[ $? = 0 ]]; then
         echo $i >>$Data_Dir/Hidden_app_Records.log
      fi
   fi
done
    [[ -n $package ]] && echo "已记录隐藏的应用到数据目录，清除搞机助手全部数据会导致记录丢失"
