#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "- 清理中"
    rm -rf $DATA_DIR/*/shared_prefs/mipush*.xml
echo "- 完成"
