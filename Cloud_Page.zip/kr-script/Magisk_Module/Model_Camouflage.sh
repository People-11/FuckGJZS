#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


mask -vc
mask $1
data=`date '+%F'`
model2=`getprop ro.product.model`
brand2=`getprop ro.product.brand`
version2=`getprop ro.build.version.incremental`


JiXing() {
echo -e "已选择伪装成$1\n"
cat <<Han >$Module/system.prop
ro.product.model=$1
ro.product.brand=$2
ro.product.manufacturer=$2
Han

printf "id=Model_Camouflage
name=机型伪装
version=$Time
versionCode=114514
author=People11
description=伪装手机型号为：$1" >$Module_XinXi
}

prop() {
cat <<Han >$Module/system.prop
ro.product.brand=${brand:=$brand2}
ro.product.manufacturer=${brand:=$brand2}
ro.product.model=${model:=$model2}
ro.build.version.incremental=${version:=$version2}
Han
}

module_prop() {
cat <<Han >$Module_XinXi
id=Model_Camouflage
name=机型伪装
version=$Time
versionCode=1
author=by：Han | 情非得已c
description=自定义伪装手机型号：$model、品牌：$brand、版本号：$version
Han
}

[[ ! -d $Module ]] && mkdir -p $Module

case $Device in
    MI11U)
        JiXing "M2102K1C" Xiaomi
    ;;

    MI10S)
        JiXing "M2102J2SC" Xiaomi
    ;;

    MI10P)
        JiXing "M2001J1E" Xiaomi
    ;;

    MIMIXF)
        JiXing "M2011J18C" Xiaomi
    ;;

    MIMIXA)
        JiXing "MIX Alpha" Xiaomi
    ;;

    RMIK40P)
        JiXing "M2012K11C" Redmi
    ;;

    RMIK40G)
        JiXing "M2012K10C" Redmi
    ;;

    RMIK30S)
        JiXing "M2007J3SC" Redmi
    ;;

    RMIK30P)
        JiXing "M2001J11C" Redmi
    ;;

    RMIN10P)
        JiXing "M2104K10AC" Redmi
    ;;

    HWP50P)
        JiXing "JAD-AL50" HUAWEI
    ;;

    HWM40RS)
        JiXing "NOP-AN00" HUAWEI
    ;;

    HWMX2)
        JiXing "TET-AN00" HUAWEI
    ;;

    HWMP11)
        JiXing "DBY-W09" HUAWEI
    ;;

    HWTVV98)
        JiXing "HD98SOKA" HUAWEI
    ;;

    IQ7)
        JiXing "V2049A" vivo
    ;;

    IQN5)
        JiXing "V2055A" vivo
    ;;

    IQ5P)
        JiXing "V2025A" vivo
    ;;

    SHARK4P)
        JiXing "SHARK KSR-A0" Xiaomi
    ;;

    SHARK4)
        JiXing "SHARK PRS-A0" Xiaomi
    ;;

    SHARK3S)
        JiXing "SHARK KLE-A0" Xiaomi
    ;;

    OP9P)
        JiXing "LE2120" OnePlus
    ;;

    OP9R)
        JiXing "LE2100" OnePlus
    ;;

    OP8P)
        JiXing "IN2020" OnePlus
    ;;

    OP8T)
        JiXing "KB2007" OnePlus
    ;;

    OPND)
        JiXing "AC2003" OnePlus
    ;;

    MZ18P)
        JiXing "Meizu M191Q" Meizu
    ;;

    MZ18)
        JiXing "Meizu M181Q" Meizu
    ;;

    MZ17P)
        JiXing "Meizu M091Q" Meizu
    ;;

    OPPOR6)
        JiXing "PEQM00" OPPO
    ;;

    OPPOA2)
        JiXing "PDHM00" OPPO
    ;;

    OPPOFX3P)
        JiXing "PEDM00" OPPO
    ;;

    STSR2)
        JiXing "DT2002C" Smartisan
    ;;

    STSP3)
        JiXing "DT1902A" Smartisan
    ;;

    STSTNTG)
        JiXing "DT2003C" Smartisan
    ;;

    APP12PM)
        JiXing "A2411" Apple
    ;;

    APPIPP129)
        JiXing "A2379" Apple
    ;;

    APPWS6)
        JiXing "A2294" Apple
    ;;

    Customize)
    prop >$Module/system.prop
    module_prop >$Module_XinXi
    ;;
esac

    [[ -f $Module/system.prop ]] && echo "机型伪装模块创建完成，模块将在下次重启时生效" && CQ
