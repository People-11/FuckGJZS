#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "0|默认"
echo "Native|原生安卓样式"
