mask $1
Choice=1
config=$Module/detach.txt

[[ -z "$package" ]] && abort "！请选择应用"

rm -rf "$config" && mktouch "$config"

for i in $package; do
    echo "- 屏蔽$i"
    echo "$i" > "$config"
done

. $Load $1
cat <<Han >$Module_XinXi
id=$id
name=$name
version=$version
versionCode=$versionCode
author=$author
description=$description
Han

test -f $Module_XinXi && echo "- $name模块创建完成" || { rm -rf $Module; abort "！$name模块创建失败"; }