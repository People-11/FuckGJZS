#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Choice=1
mask -vc
mask $1
user_versionCode=$versionCode
. $Load $1
echo
echo
echo "正在安装$name"


if [[ -d $Module && $user_versionCode -ge $versionCode ]]; then
    echo "- 已安装最新版本：${name}-$version（$versionCode）"
else
    [[ -d $Module && $user_user_versionCode -lt $versionCode ]] && echo "正在更新……" || echo "正在安装……"
    
    [[ ! -d $Module ]] && mkdir -p $Module
    cp -f "$Download_File" $Module/$id

cat <<Han >$Module_S2
#本模块由「搞机助手」创建
#特别鸣谢：by：topjohnwu & Magisk Manager提供服务支持

chmod 755 $Module/$id
$Module/$id
Han

module_prop

    if [[ -f $Module_XinXi && -f $Module_S2 ]]; then
        echo "「$name」Magisk模块创建完成，模块将在下次重启生效"
        chmod 755 $Module/$id
    fi
fi
CQ