Disable|禁用所有Magisk模块
recovery|进入recovery模式
Security_mode|进入安全模式
fastboot|进入FASTBOOT模式
9008|进入9008模式（不推荐）