Customize|自定义
MI11U|小米 11 Ultra
MI10S|小米 10S
MI10P|小米 10 Pro
MIMIXF|小米 MIX Fold
MIMIX3|小米 MIX 3
MI6|小米 6
RMIK40P|红米 K40 Pro
RMIK40G|红米 K40 游戏增强版
RMIK30S|红米 K30S 至尊纪念版
RMIK30P|红米 K30 Pro
RMIN10P|红米 Note 10 Pro
HWP50P|华为 P50 Pro
HWM40RS|华为 Mate 40 RS
HWMX2|华为 Mate X2
IQ7|IQOO 7
IQN5|IQOO NEO 5
IQ5P|IQOO 5 Pro
SHARK4P|黑鲨 4 Pro
SHARK4|黑鲨 4
SHARK3S|黑鲨 3S
OP9P|一加 9 Pro
OP9R|一加 9R
OP9|一加 9
OP8P|一加 8 Pro
OP8T|一加 8T
MZ18P|魅族 18 Pro
MZ18|魅族 18
MZ17P|魅族 17 Pro
STSR2|坚果 R2
STSP3|坚果 Pro 3
STST1|锤子 T1
APP12PM|苹果 iPhone 12 Pro Max
APPIPP129|苹果 iPad Pro 12.9英寸 第5代
APPIPM5|苹果 iPad mini 5
APPWS6|苹果 Watch Series 6
SAMS21U|三星 Galaxy S21 Ultra
SAMN20U|三星 Galaxy Note 20 Ultra
SAMZF2|三星 Galaxy Z Fold2
NOKC20P|诺基亚 C20 Plus