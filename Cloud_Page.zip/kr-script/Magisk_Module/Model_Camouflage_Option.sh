Customize|自定义
venus|小米11
draco|MIX Alpha
picasso|Redmi K30 5G
cas|小米10至尊纪念版
cmi|Mi 10 Pro
umi|Mi 10
sirius|MI 8 SE