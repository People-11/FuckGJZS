Customize|自定义
MI11U|小米 11 Ultra
MI10S|小米 10S
MI10P|小米 10 Pro
MIMIXF|小米 MIX Fold
MIMIX4|小米 MIX 4
MI6|小米 6
MICC9P|小米 CC 9 Pro
RMIK40P|红米 K40 Pro
RMIK40G|红米 K40 游戏增强版
RMIK30S|红米 K30S 至尊纪念版
RMIK30|红米 K30 至尊纪念版
RMIK30PC|红米 K30 Pro 变焦版
RMIK30P|红米 K30 Pro
RMIN10P|红米 Note 10 Pro
HWP50P|华为 P50 Pro
HWP40PP|华为 P40 Pro+
HWP40P|华为 P40 Pro
HWM40RS|华为 Mate 40 RS
HWM40P|华为 Mate 40 Pro
HWMX2|华为 Mate X2
HWMP11|华为 MatePad 11
HWMXS|华为 Mate XS
HWMX|华为 Mate X
IQ8P|IQOO 8 Pro
IQ8|IQOO 8
IQ7|IQOO 7
IQN5|IQOO NEO 5
IQ5P|IQOO 5 Pro
SHARK4P|黑鲨 4 Pro
SHARK4|黑鲨 4
SHARK3S|黑鲨 3S
OP9P|一加 9 Pro
OP9R|一加 9R
OP9|一加 9
OP8P|一加 8 Pro
OP8T|一加 8T
OP8|一加 8
MZ18P|魅族 18 Pro
MZ18|魅族 18
MZ17P|魅族 17 Pro
STSR2|坚果 R2
STSR1|坚果 R1
STSP3|坚果 Pro 3
STSP2S|坚果 Pro 2S
STST2|锤子 T2
STST1|锤子 T1
APP12PM|苹果 iPhone 12 Pro Max
APPIPP129|苹果 iPad Pro 12.9英寸 第5代
APPIPM5|苹果 iPad mini 5
APPWS6|苹果 Watch Series 6
SAMS21U|三星 Galaxy S21 Ultra
SAMS21P|三星 Galaxy S21+
SAMS21|三星 Galaxy S21
SAMN20U|三星 Galaxy Note 20 Ultra
SAMN20|三星 Galaxy Note20
SAMZF2|三星 Galaxy Z Fold2
SAMZFL5G|三星 Galaxy Z Flip 5G
SAMF|三星 Galaxy Fold
NOKC20P|诺基亚 C20 Plus
GGP|Google Pixel
GGP2|Google Pixel 2
GGP2XL|Google Pixel 2 XL
GGP3|Google Pixel 3
GGP3XL|Google Pixel 3 XL
GGP3A|Google Pixel 3a
GGP3AXL|Google Pixel 3a XL
GGP4|Google Pixel 4
GGP4XL|Google Pixel 4 XL
GGP4A|Google Pixel 4a
GGP4A5G|Google Pixel 4a 5G
GGP5|Google Pixel 5
GGPC|Google Pixel C