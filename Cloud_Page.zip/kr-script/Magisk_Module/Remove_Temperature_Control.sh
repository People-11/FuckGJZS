mask -vc
mask $1

[[ -d $Module ]] && rm -rf $Module
echo "正在移除温控"

[[ $VendorJson = 1 ]] && {
    for i in `find /vendor -iname thermal* -type f`; do
        echo "$i" | fgrep -iq 'android.' && continue
        echo - $i
        mktouch "$Module$i"
    done
}

[[ $LibThermal = 1 ]] && {
    for o in `find /system -iname thermal* -type f`; do
        echo "$o" | fgrep -iq 'android.' && continue
        echo - $o
        mktouch "$Module$o"
    done
}

[[ $LibThermalData = 1 ]] && {
    for p in `find /vendor -iname libthermal* -type f`; do
        echo "$p" | fgrep -iq 'android.' && continue
        echo - $p
        mktouch "$Module$p"
    done
}

[[ $ThermalBoost = 1 ]] && {
    for b in `find /vendor/etc/perf -iname thermal* -type f`; do
        echo "$b" | fgrep -iq 'android.' && continue
        echo - $b
        mktouch "$Module$b"
    done
}

[[ $Perf = 1 ]] && {
    for a in `find /vendor/etc/perf -iname *.xml -type f`; do
        echo "$a" | fgrep -iq 'android.' && continue
        echo - $a
        mktouch "$Module$a"
    done
    for l in `find /vendor/etc/perf -iname perf* -type f`; do
        echo "$l" | fgrep -iq 'android.' && continue
        echo - $l
        mktouch "$Module$l"
    done
    for b in `find /vendor/etc/perf -iname *conf -type f`; do
        echo "$b" | fgrep -iq 'android.' && continue
        echo - $b
        mktouch "$Module$b"
    done
}

[[ $MIUICloudThermal = 1 ]] && {
    rm -rf /data/thermal
    rm -rf /data/vendor/thermal
    touch /data/thermal
    touch /data/vendor/thermal
    /data/adb/magisk/busybox chattr +i  /data/thermal
    /data/adb/magisk/busybox chattr +i  /data/vendor/thermal
}

mktouch "$Module/uninstall.sh"
echo "/data/adb/magisk/busybox chattr -i  /data/thermal" >> "$Module/uninstall.sh"
echo "/data/adb/magisk/busybox chattr -i  /data/vendor/thermal" >> "$Module/uninstall.sh"

. $Load $1
printf "id=$id
name=$name
version=$version
versionCode=$versionCode
author=$author
description=$description" >$Module_XinXi
[[ -f $Module_XinXi ]] && echo -e "\n- 「$name」模块已创建" && CQ
