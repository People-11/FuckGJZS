# APatch检测函数
check_apatch() {
    [[ -f /data/adb/apd && -x /data/adb/apd ]]
}

# 通用的温控移除核心逻辑
remove_thermal_core() {
    local module_path="$1"
    local mktouch_func="$2"
    local busybox_path="$3"
    
    echo "正在移除温控"
    
    [[ $VendorJson = 1 ]] && {
        for b in `find "/vendor" -name "*thermal*.json" -o -name "*thermal*.conf" -type f`; do
            echo "$b" | fgrep -iq 'android.' && continue
            echo - $b
            $mktouch_func "$module_path/system/$b"
        done
    }

    [[ $VendorEX = 1 ]] && {
        for c in `find "/vendor" -name "*thermal*" ! -name "*thermal*.json" ! -name "*thermal*.conf" -type f`; do
            echo "$c" | fgrep -iq 'android.' && continue
            echo "$c" | fgrep -iq 'lib64' && continue
            echo - $c
            $mktouch_func "$module_path/system/$c"
        done
    }

    [[ $Perf = 1 ]] && {
        for d in `find "/vendor/etc/perf" -name "*.xml" -type f`; do
            echo "$d" | fgrep -iq 'android.' && continue
            echo - $d
            $mktouch_func "$module_path/system/$d"
        done
        for e in `find "/vendor/etc/perf" -name "perf*" -type f`; do
            echo "$e" | fgrep -iq 'android.' && continue
            echo - $e
            $mktouch_func "$module_path/system/$e"
        done
        for f in `find "/vendor/etc/perf" -name "*conf" -type f`; do
            echo "$f" | fgrep -iq 'android.' && continue
            echo - $f
            $mktouch_func "$module_path/system/$f"
        done
    }

    [[ $MIUICloudThermal = 1 ]] && {
        for g in `find "/data/thermal/." -type f`; do
            sed -i '/trig/d;/clr/d;/target/d' "$g"
        done
        for h in `find "/data/vendor/thermal/." -type f`; do
            sed -i '/trig/d;/clr/d;/target/d' "$h"
        done
        $busybox_path chattr +i /data/thermal/ 2>/dev/null
        $busybox_path chattr +i /data/vendor/thermal/ 2>/dev/null
    }

    # 创建卸载脚本
    $mktouch_func "$module_path/uninstall.sh"
    echo "$busybox_path chattr -i /data/thermal/" >> "$module_path/uninstall.sh"
    echo "$busybox_path chattr -i /data/vendor/thermal/" >> "$module_path/uninstall.sh"
}

# APatch专用的mktouch函数
apatch_mktouch() {
    mkdir -p "${1%/*}" 2>/dev/null
    touch "$1"
    chmod 644 "$1"
}

# APatch环境处理
if check_apatch; then
    echo "- 检测到APatch环境"
    
    # 设置APatch模块路径和工具
    MODPATH="/data/adb/modules/$1"
    [[ -d $MODPATH ]] && rm -rf $MODPATH
    
    # 获取busybox路径
    if [[ -x /data/adb/magisk/busybox ]]; then
        BUSYBOX_PATH="/data/adb/magisk/busybox"
    elif [[ -x /data/adb/ap/bin/busybox ]]; then
        BUSYBOX_PATH="/data/adb/ap/bin/busybox"
    else
        BUSYBOX_PATH="busybox"
    fi
    
    # 调用通用温控移除逻辑
    remove_thermal_core "$MODPATH" "apatch_mktouch" "$BUSYBOX_PATH"
    
    # 创建module.prop
    . $Load $1
    cat <<EOF >$MODPATH/module.prop
id=$id
name=$name
version=$version
versionCode=$versionCode
author=$author
description=$description
EOF

    if [[ -f $MODPATH/module.prop ]]; then
        echo "- 「$name」APatch模块已创建"
        echo "THE END"
        [[ -n "$ChongQi" ]] && CQ
        exit 0
    else
        echo "！APatch模块创建失败"
        exit 1
    fi
fi

# Magisk环境处理
mask -vc
mask $1

[[ -d $Module ]] && rm -rf $Module

# 调用通用温控移除逻辑（使用Magisk的mktouch和busybox）
remove_thermal_core "$Module" "mktouch" "/data/adb/magisk/busybox"

. $Load $1
module_prop
[[ -f $Module_XinXi ]] && echo -e "\n- 「$name」模块已创建" && CQ