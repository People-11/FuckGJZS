# 嘟嘟ski'Scene
# https://blog.csdn.net/minwenping/article/details/73823414

# mat4_rgb [R] [G] [B] [Saturation]
mat4_rgb() {
  values="$1 0 0 0 0 $2 0 0 0 0 $3 0 0 0 0 1"
  cmd="service call SurfaceFlinger 1015 i32 1"
  for i in $values; do
    cmd="$cmd f $i"
  done
  echo "$cmd"
  $cmd
  saturation_cmd="service call SurfaceFlinger 1022 f $4"
    echo "$saturation_cmd"
    $saturation_cmd
}
$1 $2 $3 $4 $5 $6