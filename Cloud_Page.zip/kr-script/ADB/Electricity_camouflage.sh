#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ $Percentage0 == 1 ]]; then
    adb2 -c dumpsys battery reset
    echo "已恢复默认值：`adb2 -c dumpsys battery | awk '/level/{print $2}'`"
elif [[ -n $Percentage1 ]];then
    adb2 -c dumpsys battery set level $Percentage1
    echo "已成功电量伪装为：$Percentage1"
else
    adb2 -c dumpsys battery set level $Percentage2
    echo "已成功电量伪装为：$Percentage2"
fi
