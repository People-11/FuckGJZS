#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


f [[ -n $screen_brightness ]];then
    adb2 -c settings put system screen_brightness $screen_brightness 2>/dev/null
    echo "已成功修改当前屏幕亮度为：$screen_brightness"
else
    adb2 -c settings put system screen_brightness $screen_brightness2
    echo "已成功修改当前屏幕亮度为：$screen_brightness2"
fi
    exit 0
