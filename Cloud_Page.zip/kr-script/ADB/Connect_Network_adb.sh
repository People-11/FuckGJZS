#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

echo "ip=$ip" >"$Data_Dir/Connect_Network_adb.log"
echo "port=$port" >>"$Data_Dir/Connect_Network_adb.log"
#cp -f "$Data_Dir/Connect_Network_adb.log" "$Data_Dir/Connect_Network_adb2.log"

echo "- 当前输入IP：$ip"
echo "- 当前输入端口：$port"
echo "- 当出现USB授权弹窗时，请确定USB调试，授权过的无需再次授权"
adb connect $ip:$port