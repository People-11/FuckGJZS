echo "正在注销BDUSS"
curl -s -X GET  -H "Cookie: $Input" https://passport.baidu.com/?logout
echo "BDUSS已注销"
